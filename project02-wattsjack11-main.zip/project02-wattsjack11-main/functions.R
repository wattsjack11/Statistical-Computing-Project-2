# Your Name (s2081957, wattsjack11)

# Place your function definitions that may be needed in analysis.R and report.Rmd
# in this file, including documentation.
# You can also include any needed library() calls here
MCT <- function(rand = TRUE) {
  if (isTRUE(rand)) {
    test_data <- prcp_season %>%
      group_by(Name) %>%
      mutate(Season = sample(Season)) %>%
      group_by(Name, Season)%>%
      summarise(PRCP = mean(PRCP), Rain = (sum(Rain)/n())) %>%
      summarise(PRCP = abs(diff(PRCP)), Rain = abs(diff(Rain)))

  } else {
    test_data <- prcp_season %>%
      group_by(Name, Season) %>%
      summarise(PRCP = mean(PRCP), Rain = (sum(Rain)/n())) %>%
      summarise(PRCP = abs(diff(PRCP)), Rain = abs(diff(Rain)))

  }
}
