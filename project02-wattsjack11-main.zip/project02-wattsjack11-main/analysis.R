# Your Name (s2081957, wattsjack11)
# Place analysis code that may take too long to run every time the report.Rmd
# document is run.
# Run the code in this file with
# source("analysis.R")
# in a fresh R session to ensure consistency of the results.
# Load function definitions
source("functions.R")
#### Delete this example
# Example object that could have taken a long time to compute
random_numbers <- rnorm(1000)
saveRDS(random_numbers, file = "data/random_numbers.rds")
####
suppressPackageStartupMessages(library(tidyverse))
theme_set(theme_bw())
suppressPackageStartupMessages(library(StatCompLab))
options(dplyr.summarise.inform = FALSE)
data(ghcnd_stations, package = "StatCompLab")
data(ghcnd_values, package = "StatCompLab")
ghcnd <- left_join(ghcnd_values, ghcnd_stations, by = "ID")

prcp_season = ghcnd %>%
  pivot_wider(names_from = Element, values_from = Value) %>%
  filter(!is.na(PRCP)) %>%
  mutate(Season =
           if_else(is.element(Month, c(1, 2, 3, 10, 11, 12)) == TRUE, FALSE, TRUE)
  ) %>%
  mutate(Rain =
           if_else(PRCP > 0, TRUE, FALSE)
  )
non_rand <- MCT(FALSE)
counter <- non_rand %>% mutate(PRCP = 0,
                               Rain = 0)
for (iter in c(1:10000)) {
  random <- MCT()
  random <- random %>% mutate(PRCP = if_else(
    (non_rand$PRCP < PRCP), 1, 0),
    Rain = if_else(
      (non_rand$Rain < Rain), 1, 0))
  counter <- counter %>% mutate(PRCP = PRCP + random$PRCP,
                                Rain = Rain + random$Rain)
}
p_estimate <- counter %>% mutate(PRCP = PRCP/10000,
                                 Rain = Rain/10000)

a = 0.025^(1/10000)
final <- data.frame(p_estimate$Name, p_estimate$PRCP, p_estimate$Rain)
names(final)[1] <- 'Name'
names(final)[2] <- "Test_1"
names(final)[3] <- 'Test_2'
final <- final %>%
  mutate(Test_1_CI_L =
           if_else(Test_1 > 0,  Test_1 - 2*sqrt((Test_1*(1 - Test_1))/(10000)), 0),
         Test_1_CI_U =
           if_else(Test_1 > 0, Test_1 + 2*sqrt((Test_1*(1 - Test_1))/(10000)), a),
         Test_2_CI_L = 0,
         Test_2_CI_U = a)
final
saveRDS(final, file = "data/final.rds")


monthly_average <- ghcnd %>%
  filter(Element %in% c("PRCP")) %>%
  pivot_wider(names_from = Element, values_from = Value) %>%
  group_by(ID, Name, Year, Month, Latitude, Longitude, Elevation) %>%
  filter(!is.na(PRCP)) %>%
  summarise(Mean = mean(PRCP), .groups = "drop") %>%
  mutate(sqrt_PRCP = sqrt(Mean))

data_places <- unique(monthly_average$ID)
arranged_values <- monthly_average %>% arrange(ID)
values_for_std_dev <- c()
values_for_mean <- c()

for (i in c(1:8)) {
  model <- lm(sqrt_PRCP ~
                 I(Latitude + Elevation + Longitude)^2
              + Year + sin((2*pi * Month / 7) -2.5)
              + cos((2*pi * Month / 9)-2.5),
              data = arranged_values %>%
                filter(ID != data_places[i]))
  model_prediction <- predict(model, newdata = arranged_values %>%
                                filter(ID == data_places[i]),
  se.fit = TRUE, interval = "prediction")
  values_for_mean <- c(values_for_mean, model_prediction$fit[, "fit"])
  values_for_std_dev <- c(values_for_std_dev, sqrt(model_prediction$se.fit^2 + model_prediction$residual.scale^2))
}

arranged_values$mean <- values_for_mean
arranged_values$sd <- values_for_std_dev

scores <- arranged_values %>% mutate(se = proper_score('se', sqrt_PRCP, mean = mean),
                                     ds = proper_score('ds', sqrt_PRCP, mean = mean, sd = sd))

saveRDS(scores, file = 'data/scores.rds')

# A code=readlines() code chunk in the report appendix will include the code
# in the report, without running it.
#
# You can place long-running analysis code in this file,
# and save results using
# saveRDS(object, file = "data/object.rds")
# When the results are needed in the report.Rmd file, use
# object <- readRDS(file = "data/object.rds")
# Make sure to use different filenames for each object, such as the object
# name itself.
#
# Remember to rerun this code to save new results when you change the code.
#
# The .gitignore file has been setup so that it ignores .rds files in the data/
# folder, so that you don't accidentally make git handle large binary data files.
